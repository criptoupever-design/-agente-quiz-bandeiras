package br.com.quizbandeiras.agente;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.arthenica.ffmpegkit.FFmpegKit;
import com.arthenica.ffmpegkit.ReturnCode;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Queue;

public class MainActivity extends Activity {
    private WebView webView;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Queue<TtsItem> ttsQueue = new ArrayDeque<>();
    private final Map<String, File> narrationFiles = new HashMap<>();
    private File narrationDir;
    private File incomingVideo;
    private FileOutputStream incomingStream;
    private int expectedChunks = 0;
    private int receivedChunks = 0;
    private boolean narrationInProgress = false;
    private Runnable narrationTimeout;

    private static class TtsItem {
        final String key;
        final String text;
        final File file;
        TtsItem(String key, String text, File file) { this.key = key; this.text = text; this.file = file; }
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        narrationDir = new File(getFilesDir(), "narration");
        if (!narrationDir.exists()) narrationDir.mkdirs();
        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        // The WebView loads only the bundled HTML and audio generated inside this app's private directory.
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new TtsBridge(), "AndroidTTS");
        webView.addJavascriptInterface(new VideoBridge(), "AndroidBridge");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");

        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                String engine = tts.getDefaultEngine();
                if (engine == null || !engine.toLowerCase(Locale.ROOT).contains("voxsherpa")) {
                    ttsReady = false;
                    narrationError("Configure o VoxSherpa como mecanismo de voz padrão do Android antes de gerar o vídeo.");
                    return;
                }
                int language = tts.setLanguage(Locale.forLanguageTag("pt-BR"));
                // Use a moderate pitch to avoid stressing TTS engines; console-only voice style may not be exposed through Android TTS.
                tts.setPitch(1.2f);
                tts.setSpeechRate(0.90f);
                ttsReady = language != TextToSpeech.LANG_MISSING_DATA && language != TextToSpeech.LANG_NOT_SUPPORTED;
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String utteranceId) { }
                    @Override public void onDone(String utteranceId) { main.post(() -> { cancelNarrationTimeout(); synthesizeNext(); }); }
                    @Override public void onError(String utteranceId) { main.post(() -> { cancelNarrationTimeout(); narrationInProgress = false; ttsQueue.clear(); narrationError("O mecanismo de voz não conseguiu gerar uma fala."); }); }
                    @Override public void onError(String utteranceId, int errorCode) { onError(utteranceId); }
                });
                if (!ttsReady) narrationError("O mecanismo de voz padrão não tem português brasileiro disponível. Confira o VoxSherpa e a voz instalada.");
            } else {
                narrationError("Não foi possível iniciar o mecanismo de voz do Android.");
            }
        });
    }

    private void js(String script) {
        main.post(() -> { if (webView != null) webView.evaluateJavascript(script, null); });
    }

    private void narrationError(String message) {
        js("window.onNarrationError(" + JSONObject.quote(message) + ")");
    }

    private class TtsBridge {
        @JavascriptInterface public void prepareNarration(String json) {
            main.post(() -> {
                if (!ttsReady || tts == null) {
                    narrationError("O VoxSherpa precisa estar configurado como mecanismo de voz padrão do Android, com uma voz pt-BR instalada.");
                    return;
                }
                if (narrationInProgress) {
                    narrationError("A narração anterior ainda está sendo preparada. Aguarde um momento.");
                    return;
                }
                narrationInProgress = true;
                ttsQueue.clear(); narrationFiles.clear();
                File[] old = narrationDir.listFiles();
                if (old != null) for (File f : old) { try { f.delete(); } catch (Exception ignored) { } }
                try {
                    JSONArray arr = new JSONArray(json);
                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject item = arr.getJSONObject(i);
                        String key = item.getString("key");
                        String text = item.getString("text");
                        String safe = key.replaceAll("[^a-zA-Z0-9_-]", "_");
                        File out = new File(narrationDir, safe + ".wav");
                        TtsItem task = new TtsItem(key, text, out);
                        ttsQueue.add(task); narrationFiles.put(key, out);
                    }
                    synthesizeNext();
                } catch (Exception e) {
                    narrationInProgress = false;
                    narrationError("Não consegui ler o roteiro: " + e.getMessage());
                }
            });
        }
    }

    private void cancelNarrationTimeout() {
        if (narrationTimeout != null) {
            main.removeCallbacks(narrationTimeout);
            narrationTimeout = null;
        }
    }

    private void synthesizeNext() {
        cancelNarrationTimeout();
        if (ttsQueue.isEmpty()) {
            narrationInProgress = false;
            try {
                JSONObject result = new JSONObject();
                for (Map.Entry<String, File> e : narrationFiles.entrySet()) {
                    File audio = e.getValue();
                    if (audio == null || !audio.isFile() || audio.length() < 44) {
                        narrationInProgress = false;
                        narrationError("O VoxSherpa não criou um áudio válido para: " + e.getKey() + ". Abra o VoxSherpa, confirme que a voz em português funciona e tente novamente.");
                        return;
                    }
                    result.put(e.getKey(), Uri.fromFile(audio).toString());
                }
                js("window.onNarrationPrepared(" + JSONObject.quote(result.toString()) + ")");
            } catch (Exception e) { narrationError("Falha ao preparar os áudios: " + e.getMessage()); }
            return;
        }
        TtsItem task = ttsQueue.poll();
        if (task == null) return;
        Bundle params = new Bundle();
        narrationTimeout = () -> {
            narrationTimeout = null;
            narrationInProgress = false;
            ttsQueue.clear();
            narrationError("O VoxSherpa demorou demais para gerar a fala. Verifique se a voz pt-BR está selecionada e tente novamente.");
        };
        main.postDelayed(narrationTimeout, 30000);
        int status = tts.synthesizeToFile(task.text, params, task.file, task.key);
        if (status == TextToSpeech.ERROR) {
            cancelNarrationTimeout();
            narrationInProgress = false;
            ttsQueue.clear();
            narrationError("Falha ao gerar o áudio: " + task.key + ". Confira a voz pt-BR do VoxSherpa.");
        }
    }

    private class VideoBridge {
        @JavascriptInterface public synchronized void startVideoSave(String filename, int chunks) {
            try {
                if (incomingStream != null) incomingStream.close();
                incomingVideo = new File(getCacheDir(), "quiz-source" + (filename.endsWith(".mp4") ? ".mp4" : ".webm"));
                incomingStream = new FileOutputStream(incomingVideo, false);
                expectedChunks = chunks; receivedChunks = 0;
            } catch (Exception e) { videoError("Não consegui iniciar a gravação temporária: " + e.getMessage()); }
        }
        @JavascriptInterface public void appendVideoChunk(String base64) {
            try {
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                synchronized (VideoBridge.this) {
                    if (incomingStream == null) throw new IllegalStateException("Arquivo temporário não foi iniciado.");
                    incomingStream.write(bytes); receivedChunks++;
                }
            } catch (Exception e) { videoError("Falha ao copiar o vídeo: " + e.getMessage()); }
        }
        @JavascriptInterface public void finishVideoSave() {
            main.post(() -> {
                try {
                    if (incomingStream != null) { incomingStream.flush(); incomingStream.close(); incomingStream = null; }
                    if (receivedChunks != expectedChunks) {
                        videoError("A transferência do vídeo ficou incompleta (" + receivedChunks + "/" + expectedChunks + " partes). Toque em Gerar vídeo novamente."); return;
                    }
                    if (incomingVideo == null || !incomingVideo.isFile() || incomingVideo.length() < 10000) {
                        videoError("O vídeo recebido está vazio ou incompleto."); return;
                    }
                    File mp4 = new File(getCacheDir(), "quiz-bandeiras-final.mp4");
                    String command = "-y -i " + quote(incomingVideo.getAbsolutePath()) +
                            " -c:v libx264 -preset ultrafast -crf 23 -pix_fmt yuv420p" +
                            // Keep the original captured audio unchanged for diagnosis; avoid filter artifacts.
                            " -c:a aac -b:a 192k -movflags +faststart " + quote(mp4.getAbsolutePath());
                    FFmpegKit.executeAsync(command, session -> main.post(() -> {
                        if (ReturnCode.isSuccess(session.getReturnCode()) && mp4.exists() && mp4.length() > 10000) {
                            saveToDownloads(mp4);
                        } else {
                            String detail = session.getFailStackTrace();
                            videoError("FFmpeg não conseguiu converter o vídeo. " + (detail == null ? "" : detail));
                        }
                    }));
                } catch (Exception e) { videoError("Falha ao finalizar o vídeo: " + e.getMessage()); }
            });
        }
    }

    private String quote(String path) { return "\"" + path.replace("\"", "\\\"") + "\""; }

    private void saveToDownloads(File source) {
        try {
            ContentValues values = new ContentValues();
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, "quiz-bandeiras.mp4");
            values.put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4");
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/QuizBandeiras");
                values.put(MediaStore.MediaColumns.IS_PENDING, 1);
            }
            Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new IllegalStateException("O Android não criou o arquivo de saída.");
            try (FileInputStream in = new FileInputStream(source); OutputStream out = getContentResolver().openOutputStream(uri)) {
                if (out == null) throw new IllegalStateException("Não consegui abrir o arquivo de saída.");
                byte[] buf = new byte[1024 * 1024]; int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentValues done = new ContentValues(); done.put(MediaStore.MediaColumns.IS_PENDING, 0);
                getContentResolver().update(uri, done, null, null);
            }
            js("window.onVideoSaved(" + JSONObject.quote("Download/QuizBandeiras/quiz-bandeiras.mp4") + ")");
        } catch (Exception e) { videoError("Não consegui salvar em Downloads: " + e.getMessage()); }
    }

    private void videoError(String message) { js("window.onVideoSaveError(" + JSONObject.quote(message) + ")"); }

    @Override public void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        if (webView != null) { webView.removeJavascriptInterface("AndroidTTS"); webView.removeJavascriptInterface("AndroidBridge"); webView.destroy(); }
        try { if (incomingStream != null) incomingStream.close(); } catch (Exception ignored) { }
        super.onDestroy();
    }
}
