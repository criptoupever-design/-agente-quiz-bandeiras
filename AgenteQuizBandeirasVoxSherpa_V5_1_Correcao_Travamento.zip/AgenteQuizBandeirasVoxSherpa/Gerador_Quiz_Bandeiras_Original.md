# 🎬 Gerador de Quiz de Bandeiras

Uma pergunta por linha: bandeira | resposta | curiosidade

Texto da pergunta

Formato

Tema

Segundos para pensar

Segundos da curiosidade

[x] Mostrar mascote (Robô Beep) [ ] Narração automática (voz do aparelho) [ ] Gravar pelo microfone Narração: o navegador não deixa gravar a voz do aparelho direto. Para ela entrar no vídeo, ligue as duas opções, use o volume médio, sem fone e em lugar silencioso. Ou desligue a voz automática, ligue só o microfone e narre você mesma(o).

O vídeo é gravado em tempo real: mantenha a tela ligada e esta aba aberta até terminar.