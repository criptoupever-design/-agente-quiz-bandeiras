# Agente Quiz de Bandeiras — VoxSherpa offline

Projeto Android de protótipo para simplificar o Gerador de Quiz de Bandeiras no POCO X6 Pro.

## V4 — introdução e encerramento

Esta versão adiciona campos editáveis para a fala de abertura e a fala final. A abertura apresenta o Robô Beep e explica o desafio; o encerramento pede pontuação nos comentários, like, inscrição e compartilhamento. As duas falas são sintetizadas pelo VoxSherpa junto com as falas das perguntas, respostas e curiosidades. As cenas têm duração ajustada à duração do áudio gerado.

## O que pretende automatizar

1. Você edita as perguntas no HTML existente.
2. Toca em **Gerar vídeo**.
3. O app Android usa o mecanismo de voz padrão do aparelho para gerar cada fala em arquivo WAV. Para usar o VoxSherpa, ele precisa estar definido como mecanismo TTS padrão do Android e ter uma voz pt-BR instalada.
4. As falas são reproduzidas no tempo de cada cena e incluídas na gravação.
5. O FFmpeg converte o vídeo gravado para MP4 e salva em `Download/QuizBandeiras/quiz-bandeiras.mp4`.

Não é necessário instalar Piper separadamente, nem exportar/renomear arquivos WAV manualmente.

## Importante sobre o estado do projeto

Este ZIP contém **código-fonte Android**, não um APK pronto. A sintaxe JavaScript da página foi verificada, mas o APK V4 precisa ser compilado no GitHub Actions e instalado/testado no aparelho. A V3 já foi testada no POCO X6 Pro; as novas cenas da V4 ainda precisam de teste no dispositivo.

## Pré-requisitos

- Android 10 ou mais recente.
- VoxSherpa instalado, com um modelo/voz pt-BR funcional.
- Definir VoxSherpa como mecanismo de conversão de texto em voz padrão nas configurações Android: Configurações → Idiomas/Entrada (o nome pode variar) → Saída de texto para voz → mecanismo preferido → VoxSherpa.
- Internet é necessária apenas para baixar dependências ao compilar o APK; a geração de narração e vídeo é local depois de instalado.

## Gerar o APK pelo GitHub Actions

1. Crie um repositório GitHub e envie os arquivos deste projeto.
2. Abra a aba **Actions**.
3. Execute o workflow **Build APK**.
4. Baixe o artefato `AgenteQuizBandeiras-debug-apk` e instale o APK no celular.

Esse processo ainda exige uma compilação inicial. Depois de instalado e configurado, o objetivo é gerar cada vídeo com um único toque.

## Estrutura

- `app/src/main/assets/index.html`: gerador com campos editáveis de introdução/encerramento e narração nativa.
- `app/src/main/java/br/com/quizbandeiras/agente/MainActivity.java`: WebView, TTS Android e exportação/conversão.
- `app/build.gradle`: dependência FFmpegKit usada para gerar o MP4.
- `.github/workflows/build-apk.yml`: compilação automática do APK debug.

## Limitações conhecidas do protótipo

- A disponibilidade de português brasileiro depende da voz instalada no VoxSherpa.
- A introdução e o encerramento adicionados na V4 ainda precisam ser testados no POCO X6 Pro.
- O FFmpegKit é empacotado por meio de uma distribuição mantida por terceiros. O projeto usa a variante GPL para incluir o codificador H.264. Se o aplicativo for distribuído publicamente/comercialmente, será necessário revisar as obrigações da licença GPL antes da distribuição.


## V5 - voz e áudio
- Aplica pitch 2.00 e velocidade 1.12x nas chamadas Android TTS, conforme os valores visíveis no VoxSherpa Console do usuário.
- Remove o tom portador de 40 Hz que era adicionado continuamente à faixa gravada.
- Aplica tratamento leve de áudio na conversão final (filtro passa-altas, redução de ruído e limitador).
- Nota: o Android TTS não oferece acesso universal a todos os controles internos do console (por exemplo, Voice Style proprietário). A seleção de modelo/estilo efetivamente usada continua dependendo do mecanismo VoxSherpa instalado e da sua configuração.


## V6 — ajustes de narração e sincronização
A V6 reduz a taxa de fala do mecanismo Android TTS para 0,90x, acrescenta margem após a duração medida de cada clipe e interrompe clipes anteriores nas transições para evitar falas sobrepostas. A conversão final continua sem filtros de áudio e usa AAC a 192 kb/s, para preservar a correção de chiado da V5.2. Teste o APK gerado com um vídeo curto antes de produzir um lote completo.
