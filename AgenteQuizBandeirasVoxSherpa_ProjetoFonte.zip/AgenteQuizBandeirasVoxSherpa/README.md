# Agente Quiz de Bandeiras — VoxSherpa offline

Projeto Android de protótipo para simplificar o Gerador de Quiz de Bandeiras no POCO X6 Pro.

## O que pretende automatizar

1. Você edita as perguntas no HTML existente.
2. Toca em **Gerar vídeo**.
3. O app Android usa o mecanismo de voz padrão do aparelho para gerar cada fala em arquivo WAV. Para usar o VoxSherpa, ele precisa estar definido como mecanismo TTS padrão do Android e ter uma voz pt-BR instalada.
4. As falas são reproduzidas no tempo de cada cena e incluídas na gravação.
5. O FFmpeg converte o vídeo gravado para MP4 e salva em `Download/QuizBandeiras/quiz-bandeiras.mp4`.

Não é necessário instalar Piper separadamente, nem exportar/renomear arquivos WAV manualmente.

## Importante sobre o estado do projeto

Este ZIP contém **código-fonte Android**, não um APK pronto. O ambiente em que este pacote foi preparado não tem Android SDK/Gradle para compilar e validar o APK. O fluxo de integração com TTS/FFmpeg precisa ser compilado e testado no dispositivo antes de ser considerado pronto para uso. O workflow em `.github/workflows/build-apk.yml` tenta gerar um APK debug no GitHub Actions.

## Pré-requisitos

- Android 10 ou mais recente.
- VoxSherpa instalado, com um modelo/voz pt-BR funcional.
- Definir VoxSherpa como mecanismo de conversão de texto em voz padrão nas configurações Android: Configurações → Idiomas/Entrada (o nome pode variar) → Saída de texto para voz → mecanismo preferido → VoxSherpa.
- Internet é necessária apenas para baixar dependências ao compilar o APK; a geração de narração e vídeo é local depois de instalado.

## Gerar o APK pelo GitHub Actions

1. Crie um repositório GitHub e envie os arquivos deste projeto.
2. Abra a aba **Actions**.
3. Execute o workflow **Build APK**.
4. Baixe o artefato `AgenteQuizBandeiras-debug-apk` e instale o APK no celular.

Esse processo ainda exige uma compilação inicial. Depois de instalado e configurado, o objetivo é gerar cada vídeo com um único toque.

## Estrutura

- `app/src/main/assets/index.html`: gerador HTML original adaptado para pedir narração nativa.
- `app/src/main/java/br/com/quizbandeiras/agente/MainActivity.java`: WebView, TTS Android e exportação/conversão.
- `app/build.gradle`: dependência FFmpegKit usada para gerar o MP4.
- `.github/workflows/build-apk.yml`: compilação automática do APK debug.

## Limitações conhecidas do protótipo

- A disponibilidade de português brasileiro depende da voz instalada no VoxSherpa.
- O projeto precisa de compilação e teste real; ainda não foi validado no POCO X6 Pro.
- O FFmpegKit é empacotado por meio de uma distribuição mantida por terceiros. O projeto usa a variante GPL para incluir o codificador H.264. Se o aplicativo for distribuído publicamente/comercialmente, será necessário revisar as obrigações da licença GPL antes da distribuição.
